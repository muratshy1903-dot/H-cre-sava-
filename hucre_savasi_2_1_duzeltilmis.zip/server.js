const express=require("express"),http=require("http"),WebSocket=require("ws"),Database=require("better-sqlite3"),bcrypt=require("bcryptjs"),crypto=require("crypto"),path=require("path");
const app=express(),server=http.createServer(app),wss=new WebSocket.Server({server}),db=new Database("hucre.db");
app.use(express.json());app.use(express.static(path.join(__dirname,"public")));
db.exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT UNIQUE,password TEXT,name TEXT,gold INTEGER DEFAULT 100,skin TEXT DEFAULT '#568b63')");
const sessions=new Map();
app.post("/api/register",(q,s)=>{let {email,password,name}=q.body||{};if(!email||!password||password.length<6||!name)return s.status(400).json({error:"E-posta, ad ve en az 6 karakter şifre gerekli."});try{let h=bcrypt.hashSync(password,10),r=db.prepare("INSERT INTO users(email,password,name) VALUES(?,?,?)").run(email.toLowerCase(),h,String(name).slice(0,15)),t=crypto.randomBytes(32).toString("hex");sessions.set(t,r.lastInsertRowid);s.json({token:t})}catch(e){s.status(409).json({error:"Bu e-posta zaten kayıtlı."})}});
app.post("/api/login",(q,s)=>{let u=db.prepare("SELECT * FROM users WHERE email=?").get((q.body?.email||"").toLowerCase());if(!u||!bcrypt.compareSync(q.body?.password||"",u.password))return s.status(401).json({error:"Giriş bilgileri yanlış."});let t=crypto.randomBytes(32).toString("hex");sessions.set(t,u.id);s.json({token:t})});
const WORLD=9000,foods=[],viruses=[],players=new Map(),C=["#6b879b","#a65f5f","#7a6d8f","#5e8a78","#9a7a55","#6f7d58","#8b6870"],R=(a,b)=>Math.random()*(b-a)+a,D=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
for(let i=0;i<1800;i++)foods.push({x:R(20,WORLD-20),y:R(20,WORLD-20),r:R(5,9),col:C[i%C.length]});
for(let i=0;i<65;i++)viruses.push({x:R(200,WORLD-200),y:R(200,WORLD-200),r:35});
const speed=r=>Math.max(1.1,7.8-Math.sqrt(r)*.4),clean=p=>({x:p.x,y:p.y,r:p.r,name:p.name,skin:p.skin,gold:p.gold});
wss.on("connection",ws=>{let p=null,uid=null,id=crypto.randomBytes(8).toString("hex");
ws.on("message",raw=>{try{let m=JSON.parse(raw);
if(m.t==="auth"){uid=sessions.get(m.token);let u=uid&&db.prepare("SELECT * FROM users WHERE id=?").get(uid);if(!u)return ws.send(JSON.stringify({t:"error",msg:"Oturum geçersiz"}));p={x:WORLD/2+R(-500,500),y:WORLD/2+R(-500,500),r:35,name:u.name,skin:u.skin,gold:u.gold};players.set(id,{ws,p,uid});return}
if(!p)return;
if(m.t==="input"){let dx=Number(m.x)-innerWidth/2,dy=Number(m.y)-innerHeight/2,L=Math.hypot(dx,dy)||1;p.x=Math.max(p.r,Math.min(WORLD-p.r,p.x+dx/L*speed(p.r)));p.y=Math.max(p.r,Math.min(WORLD-p.r,p.y+dy/L*speed(p.r)))}
if(m.t==="feed"){let n=Math.max(1,Math.min(50,m.count||1));if(p.r<12)return;let actual=Math.min(n,Math.floor(p.r));for(let i=0;i<actual;i++){let a=Number(m.angle)||0;foods.push({x:p.x+Math.cos(a)*p.r*1.15,y:p.y+Math.sin(a)*p.r*1.15,r:5,col:"#777"});p.r=Math.sqrt(Math.max(64,p.r*p.r-1))}}
if(m.t==="spend"){let n=m.amount===100?100:10;if(p.gold>=n){p.gold-=n;db.prepare("UPDATE users SET gold=? WHERE id=?").run(p.gold,uid)}}
if(m.t==="split"&&p.r>45){p.r/=Math.sqrt(2)}
}catch{}});ws.on("close",()=>players.delete(id))});
setInterval(()=>{for(let [id,o] of players){let p=o.p;
for(let i=foods.length-1;i>=0;i--)if(D(p,foods[i])<p.r){p.r=Math.sqrt(p.r*p.r+foods[i].r*foods[i].r*.45);p.gold++;foods[i]={x:R(20,WORLD-20),y:R(20,WORLD-20),r:R(5,9),col:C[(Math.random()*C.length)|0]}}
for(const v of viruses)if(D(p,v)<p.r+v.r*.55&&p.r>v.r){p.r*=.72;p.x=R(200,WORLD-200);p.y=R(200,WORLD-200);p.gold=Math.max(0,p.gold-5)}
for(const [id2,o2] of players){if(id===id2)continue;let q=o2.p;if(D(p,q)<Math.max(p.r,q.r)*.7){if(p.r>q.r*1.12){p.r=Math.sqrt(p.r*p.r+q.r*q.r*.7);p.gold+=10;q.r=35;q.x=R(200,WORLD-200);q.y=R(200,WORLD-200)}else if(q.r>p.r*1.12){p.r=35;p.x=R(200,WORLD-200);p.y=R(200,WORLD-200);p.gold=Math.max(0,p.gold-10)}}}
db.prepare("UPDATE users SET gold=?,skin=? WHERE id=?").run(p.gold,p.skin,o.uid)}
let all=[...players.values()].map(o=>clean(o.p));for(let o of players.values())if(o.ws.readyState===1)o.ws.send(JSON.stringify({t:"state",me:clean(o.p),players:all.filter(q=>q.name!==o.p.name),foods,viruses}))},50);
server.listen(process.env.PORT||8080,()=>console.log("Hücre Savaşı hazır"));
